package org.ywb.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.ywb.demo.pojo.User;

/**
 * @author YuWenbo
 * e-mail 18629015421@163.com
 * github https://github.com/xiao-ren-wu
 * @version 1
 * @since 2019/6/29 12:18
 */

public interface UserService extends IService<User> {
}
