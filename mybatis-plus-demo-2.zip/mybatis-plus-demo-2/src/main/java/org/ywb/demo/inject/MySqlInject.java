package org.ywb.demo.inject;

import com.baomidou.mybatisplus.core.injector.AbstractMethod;
import com.baomidou.mybatisplus.core.injector.DefaultSqlInjector;
import org.springframework.stereotype.Component;
import org.ywb.demo.method.DeleteAllMethod;

import java.util.List;

/**
 * @author yuwenbo1
 * email: yuwenbo10@jd.com
 * copyright: © 2019  智能城市icity.jd.com ALL Right Reserved
 * @version v1.0.0
 * <p>
 * </p>
 * @date 2019/10/2 15:05
 */
@Component
public class MySqlInject extends DefaultSqlInjector {
    @Override
    public List<AbstractMethod> getMethodList(Class<?> mapperClass) {
        List<AbstractMethod> methodList = super.getMethodList(mapperClass);
        methodList.add(new DeleteAllMethod());
        return methodList;
    }
}
