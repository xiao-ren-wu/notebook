package org.ywb.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.ywb.demo.dao.UserMapper;
import org.ywb.demo.pojo.User;

import javax.annotation.Resource;

/**
 * @author yuwenbo1
 * email: yuwenbo10@jd.com
 * copyright: © 2019  智能城市icity.jd.com ALL Right Reserved
 * @version v1.0.0
 * <p>
 * </p>
 * @date 2019/10/2 10:37
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class MyTest {
    @Resource
    private UserMapper userMapper;

    @Test
    public void deleteById(){
        userMapper.deleteById(4566L);
    }
    @Test
    public void selectIgnoreDeleteTest(){
        userMapper.selectById(3456L);
    }
    @Test
    public void selectMyselfSqlTest(){
        userMapper.selectAll().forEach(System.out::println);
    }

    @Test
    public void fillTest(){
        User user = new User();
        user.setAge(32);
        user.setEmail("test@163.com");
        user.setName("大佬");
        user.setId(12344L);
        user.setManagerId(1234L);
        userMapper.insert(user);
    }

    @Test
    public void testLock(){
        int version = 1;
        User user = new User();
        user.setEmail("wtf@163.com");
        user.setAge(34);
        user.setId(2345L);
        user.setManagerId(1234L);
        user.setVersion(1);
        userMapper.updateById(user);

    }

    @Test
    public void deleteAll(){
        userMapper.deleteAll();
    }
}
